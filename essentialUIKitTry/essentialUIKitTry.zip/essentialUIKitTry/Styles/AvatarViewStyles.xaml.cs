﻿using Xamarin.Forms.Xaml;

namespace essentialUIKitTry.Styles
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AvatarViewStyles
    {
        public AvatarViewStyles()
        {
            this.InitializeComponent();
        }
    }
}