﻿using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;

namespace essentialUIKitTry.Styles
{
    [Preserve(AllMembers = true)]
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BorderStyles
    {
        public BorderStyles()
        {
            this.InitializeComponent();
        }
    }
}